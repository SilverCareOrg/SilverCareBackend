
fields = {
    
	       "Religie" : [ "credinta", "dumnezeu", "biserica", "preot", "rugaciune", "spiritualitate",
    	       			 "sfant", "evanghelie", "credincios", "templu", "dogma", "predica", 
   	       				 "pacat", "sacrificiu", "preotie", "ortodox", "sinagoga", "moschee",
    	       			 "biserica ortodoxa", "vatican", "credo", "har", "ingeri", "inviere", "botez",
   	       				 "sfanta scriptura", "apostol", "biserica catolica", "pelerinaj", "moaste", 
    	       			 "manastire", "manastiri", "manastirile", "biserici", "bisericile" ], 
		

	       "Terapie" :  [ "terapie","terapeut","pacient","tratament","sanatate","recuperare",
		   				 "psihoterapie","fizioterapie","consiliere","medicament", "reabilitare",
    		   			 "suport","analiza","sesiune","interventie","progres","psihologie","abordare",
    		   			 "emoțional","terapie cognitiv-comportamentala","terapie de grup",
		   				 "terapie familiala","terapie ocupationala", "suparare", "depresie", 
	           			 "anxietate", "deceptie", "deceptii", "dezvoltate", "socio-emotionala",
		   				 "sociala", "emotionala", "consiliere", "cuplu", "familie", "grup", "grup social" ],
        

		    "Alimentatie" : [ "alimentatie", "nutritie", "aliment", "consum", "hrana", "echilibrat",
  							  "dieta", "calorii", "vitamine", "mineral", "proteine", "carbohidrati",
  							  "grasimi", "fibra", "apa", "nutrienti", "salata", "fructe", "legume",
  							  "cereale", "producator", "fast-food", "digestie", "sanatate", "obezitate",
  							  "regim", "supliment", "gustare", "echilibru", "control", "nutritie", "sanatate",
                              "culinar", "culinara" ]
            
				  }
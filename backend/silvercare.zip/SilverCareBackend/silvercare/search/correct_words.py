    
correct_words = ['pelerinaj', 'manastirile', 'rupestre', 'grup', 'dezvoltare', 'personala', 'socio-emotionala',
                 'emotionala', 'sedinta', 'terapie', 'psihologica', 
                 'clinica', 'individuala', 'cuplu', 'familie', 'culinara', 
                 'coaching', 'nutritie', "credinta", "dumnezeu", "biserica", "preot", "rugaciune", "sfant", 
                 "evanghelie", "credinta", "templu", "preotie", "ortodox", "har", "ingeri", "inviere", 
                 "botez","apostol",  "pelerinaj", "moaste", "manastire", "biserici", "psihoterapie","fizioterapie","consiliere",
                  "alimentatie", "nutritie", "aliment", "consum", "hrana", "echilibrat","consiliere", "cuplu", "familie", "grup",
                  'psiho'       
                ]

seplist = [
        'cu', 'Cu', 'de', 'De', 'din', 'Din', 'la', 'La', 'pe', 'Pe', 
        'prin', 'Prin', 'in', 'In', 'si', 'Si', 'sau', 'Sau'

]

